#!/usr/bin/env bash
set -euo pipefail

# ZAWSZE używamy microk8s kubectl
KUBECTL=(microk8s kubectl)

NS="free5gc"

GOOD_POD="upf-net-ok-cni"
BAD_POD="upf-net-bad-cni"

echo "==[TC-UPF-4] Walidacja adresacji dataplane (DATA_CIDR) dla anotacji networks =="

echo
echo "==[TC-UPF-4] Sprzątanie poprzednich Podów =="
"${KUBECTL[@]}" -n "${NS}" delete pod "${GOOD_POD}" "${BAD_POD}" \
  --ignore-not-found=true >/dev/null 2>&1 || true

echo
echo "==[TC-UPF-4] Krok 1: Pod z poprawnym IP w DATA_CIDR (${GOOD_POD}) =="

cat <<POD | "${KUBECTL[@]}" -n "${NS}" apply -f -
apiVersion: v1
kind: Pod
metadata:
  name: ${GOOD_POD}
  labels:
    app.kubernetes.io/part-of: free5gc
    project: free5gc
    nf: upf
  annotations:
    5g.kkarczmarek.dev/validate-dataplane-cidr: "true"
    # webhook szuka IP/prefix w tym stringu:
    # tutaj 10.100.10.5/24 mieści się w 10.100.0.0/16 (DATA_CIDR)
    k8s.v1.cni.cncf.io/networks: "n6-net@10.100.10.5/24"
spec:
  containers:
  - name: main
    image: docker.io/library/busybox:1.36
    command: ["sh","-c","sleep 3600"]
POD

echo
echo "  -> Pod ${GOOD_POD} został utworzony (IP wpada w DATA_CIDR)"
"${KUBECTL[@]}" -n "${NS}" get pod "${GOOD_POD}" -o wide

echo
echo "==[TC-UPF-4] Krok 2: Pod z IP poza DATA_CIDR (${BAD_POD}) – spodziewany DENY =="

set +e
APPLY_OUT=$(
cat <<POD | "${KUBECTL[@]}" -n "${NS}" apply -f - 2>&1
apiVersion: v1
kind: Pod
metadata:
  name: ${BAD_POD}
  labels:
    app.kubernetes.io/part-of: free5gc
    project: free5gc
    nf: upf
  annotations:
    5g.kkarczmarek.dev/validate-dataplane-cidr: "true"
    # 192.168.10.5/24 jest poza 10.100.0.0/16
    k8s.v1.cni.cncf.io/networks: "n6-net@192.168.10.5/24"
spec:
  containers:
  - name: main
    image: docker.io/library/busybox:1.36
    command: ["sh","-c","sleep 3600"]
POD
)
RC=$?
set -e

echo
if [ "${RC}" -eq 0 ]; then
  echo "!! OCZEKIWANE ODRZUCENIE, ale Pod ${BAD_POD} został utworzony (coś jest nie tak z walidacją)"
  "${KUBECTL[@]}" -n "${NS}" get pod "${BAD_POD}" -o wide || true
else
  echo "OK – webhook odrzucił ${BAD_POD}:"
  echo "---------------------------------------"
  echo "${APPLY_OUT}"
  echo "---------------------------------------"
fi

echo
echo "==[TC-UPF-4] Podsumowanie =="
echo "  - ${GOOD_POD}: IP w DATA_CIDR → request ACCEPT."
echo "  - ${BAD_POD}: IP poza DATA_CIDR → request DENY przez admission webhook."
echo
echo "Pod ${GOOD_POD} zostaje w namespace ${NS} do dalszej analizy."
echo "W razie potrzeby usuń oba Pody:"
echo "  ${KUBECTL[*]} -n ${NS} delete pod ${GOOD_POD} ${BAD_POD} --ignore-not-found=true"

